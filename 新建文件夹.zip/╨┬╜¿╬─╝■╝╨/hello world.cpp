#include  <iostream>
using namespace std;
int main()
{
	int age;

	cout << "please input your age:" << endl;
	cin >> age;

	cout << "hello world!I am " << age << endl;

	return 0;
}